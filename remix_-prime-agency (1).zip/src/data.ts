/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface WholesaleProduct {
  id: string;
  name: string;
  category: 'household' | 'packing';
  subCategory: string; // e.g., Cleaning, Kitchen accessories, Plastic items, Storage containers, Bubble wrap, Tape, Corrugated boxes, Carry bags, Packaging rolls
  description: string;
  tagline: string;
  wholesalePrice: number; // in INR per bundle/pack
  unitName: string; // e.g. "Pack of 50", "Roll of 100m", "Carton of 25"
  minOrderQty: number; // minimum bundles/units
  gstRate: number; // typically 18% or 12%
  isAvailable: boolean;
  imageUrl?: string;
  resellerInfo?: {
    estimatedRetailMargin: string;
    targetRetailSegment: string;
    packagingOptions: string;
  };
  specifications: { [key: string]: string };
  blueprintShape: {
    neckWidth: number;
    neckLength: number;
    shoulderWidth: number;
    shoulderHeight: number;
    bellyWidth: number;
    bellyHeight: number;
    baseWidth: number;
    totalHeightCm: number;
  };
}

export const FEATURED_BRANDS = [
  { name: 'Supreme Polymers', logo: 'SP' },
  { name: 'Milma Co-op Supplies', logo: 'MC' },
  { name: 'Cello Housewares', logo: 'CH' },
  { name: 'Trivandrum Plastics Co', logo: 'TP' },
  { name: 'Prestige Commercial', logo: 'PC' },
  { name: '3M Industrial Kerala', logo: '3M' }
];

export const KERALA_DISTRICTS = [
  'Thiruvananthapuram'
];

export const WHOLESALE_PRODUCTS: WholesaleProduct[] = [
  // --- HOUSEHOLD ITEMS ---
  {
    id: 'h-01',
    name: 'Heavy-Duty Commercial Floor Squeegee',
    category: 'household',
    subCategory: 'Cleaning products',
    tagline: 'Dual-lip vulcanized rubber squeegee for commercial floors and spas.',
    description: 'Constructed from powder-coated high-gauge steel with a reinforced 60cm twin-foam rubber blade. Ideal for large tiles, hospitality floors, and Kerala high-humidity monsoon drying cycles.',
    wholesalePrice: 420,
    unitName: 'Carton of 10 units',
    minOrderQty: 5,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1581578731548-c64695cc6954?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Blade Width': '60 cm',
      'Material': 'Anodized Steel + Foam Rubber',
      'Handle Compatibility': '25mm standard thread',
      'Durability Rating': 'Ultra Tough Grade'
    },
    blueprintShape: {
      neckWidth: 0.25,
      neckLength: 0.15,
      shoulderWidth: 0.95,
      shoulderHeight: 0.70,
      bellyWidth: 0.45,
      bellyHeight: 0.20,
      baseWidth: 0.75,
      totalHeightCm: 120
    }
  },
  {
    id: 'h-02',
    name: 'Airtight Stackable Dry Food Storage Canisters',
    category: 'household',
    subCategory: 'Storage containers',
    tagline: 'Premium modular space-saving storage jars with silicone airtight lock.',
    description: 'Made of virgin bpa-free shockproof acrylic, featuring our dual-action airtight latch lock. Excellent storage integrity for sugar, spices, flour, and tea powder in coastal retail supermarkets.',
    wholesalePrice: 1850,
    unitName: 'Set of 6 Jars (Box Pack)',
    minOrderQty: 10,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Volume Spec': '1.2L, 0.8L, 0.5L Jars',
      'Seal Compound': 'Food-Grade Silicone',
      'Stackability': 'Modular Interlock',
      'Transparency': 'Stained Crystal Clear'
    },
    blueprintShape: {
      neckWidth: 0.75,
      neckLength: 0.10,
      shoulderWidth: 0.65,
      shoulderHeight: 0.45,
      bellyWidth: 0.82,
      bellyHeight: 0.35,
      baseWidth: 0.60,
      totalHeightCm: 28
    }
  },
  {
    id: 'h-03',
    name: 'Unbreakable Commercial Water Basins (65L)',
    category: 'household',
    subCategory: 'Plastic items',
    tagline: 'Industrial virgin polymer washing tubs with thick-walled reinforcement rims.',
    description: 'High-capacity heavy washing buckets utilizing flex-core virgin HDPE. Resistant to chemical bleach, deep hot-temperature baths, and heavy load transit for commercial catering and luxury hotels.',
    wholesalePrice: 3200,
    unitName: 'Bundle of 15 Basins',
    minOrderQty: 3,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Capacity': '65 Liters',
      'Material': 'Virgin HDPE Polymer',
      'Load Index': 'Up to 120 kg Static',
      'Color Option': 'Deep Navy / Traffic Orange'
    },
    blueprintShape: {
      neckWidth: 0.90,
      neckLength: 0.12,
      shoulderWidth: 0.80,
      shoulderHeight: 0.55,
      bellyWidth: 1.10,
      bellyHeight: 0.40,
      baseWidth: 0.72,
      totalHeightCm: 45
    }
  },
  {
    id: 'h-04',
    name: 'Premium Brushed Stainless Steel Pedal Bins',
    category: 'household',
    subCategory: 'Kitchen accessories',
    tagline: 'Fingerprint-proof silent-close metal dustbins for hotels & kitchens.',
    description: 'Fitted with a solid steel step pedal mechanism engineered for over 100,000 presses and a slow-closing safety damper lid. Perfect for restaurant washrooms, luxury suites, and domestic pantries.',
    wholesalePrice: 1450,
    unitName: 'Individual Premium Carton',
    minOrderQty: 12,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1610557892470-7617478aa836?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Capacity': '12 Liters',
      'Mechanism': 'Steel Pedal & Air Damper',
      'Finish': 'Polished Stainless Steel Anti-Smudge',
      'Inner Bucket': 'Removable PP with Bag Lock'
    },
    blueprintShape: {
      neckWidth: 0.50,
      neckLength: 0.15,
      shoulderWidth: 0.55,
      shoulderHeight: 0.65,
      bellyWidth: 0.60,
      bellyHeight: 0.30,
      baseWidth: 0.52,
      totalHeightCm: 42
    }
  },
  {
    id: 'h-05',
    name: 'EVA Soap Case (Solid Pastel) - Pink',
    category: 'household',
    subCategory: 'Plastic items',
    tagline: 'Premium BPA-free double-tray design in soothing solid pink.',
    description: 'A durable, premium grade solid-hue pastel soap case utilizing 100% food-grade virgin polymers. Features an inner dry-drainage tray that separates soap from water to prevent waste.',
    wholesalePrice: 270,
    unitName: 'Box of 12 Cases (Pink)',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1607006342460-7a32ea3fa879?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Color Option': 'Solid Pink',
      'Material': '100% Virgin BPA-Free PP',
      'Features': 'Inner Drainage Tray',
      'Retail MRP': '₹65 per piece',
      'Wholesale Rate': '₹22.50 per piece'
    },
    blueprintShape: {
      neckWidth: 0.85,
      neckLength: 0.08,
      shoulderWidth: 0.80,
      shoulderHeight: 0.35,
      bellyWidth: 0.95,
      bellyHeight: 0.25,
      baseWidth: 0.75,
      totalHeightCm: 12
    }
  },
  {
    id: 'h-06',
    name: 'EVA Soap Case (Solid Pastel) - Blue',
    category: 'household',
    subCategory: 'Plastic items',
    tagline: 'Premium BPA-free double-tray design in soothing solid blue.',
    description: 'A durable, premium grade solid-hue pastel soap case utilizing 100% food-grade virgin polymers. Features an inner dry-drainage tray that separates soap from water to prevent waste.',
    wholesalePrice: 270,
    unitName: 'Box of 12 Cases (Blue)',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Color Option': 'Solid Blue',
      'Material': '100% Virgin BPA-Free PP',
      'Features': 'Inner Drainage Tray',
      'Retail MRP': '₹65 per piece',
      'Wholesale Rate': '₹22.50 per piece'
    },
    blueprintShape: {
      neckWidth: 0.85,
      neckLength: 0.08,
      shoulderWidth: 0.80,
      shoulderHeight: 0.35,
      bellyWidth: 0.95,
      bellyHeight: 0.25,
      baseWidth: 0.75,
      totalHeightCm: 12
    }
  },
  {
    id: 'h-07',
    name: 'EVA Soap Case (Solid Pastel) - Beige',
    category: 'household',
    subCategory: 'Plastic items',
    tagline: 'Premium BPA-free double-tray design in elegant solid beige.',
    description: 'A durable, premium grade solid-hue pastel soap case utilizing 100% food-grade virgin polymers. Features an inner dry-drainage tray that separates soap from water to prevent waste.',
    wholesalePrice: 270,
    unitName: 'Box of 12 Cases (Beige)',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1605264964528-06403738d6df?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Color Option': 'Solid Beige',
      'Material': '100% Virgin BPA-Free PP',
      'Features': 'Inner Drainage Tray',
      'Retail MRP': '₹65 per piece',
      'Wholesale Rate': '₹22.50 per piece'
    },
    blueprintShape: {
      neckWidth: 0.85,
      neckLength: 0.08,
      shoulderWidth: 0.80,
      shoulderHeight: 0.35,
      bellyWidth: 0.95,
      bellyHeight: 0.25,
      baseWidth: 0.75,
      totalHeightCm: 12
    }
  },
  {
    id: 'h-08',
    name: 'EVA Soap Case (Crystal Dot) - Pink',
    category: 'household',
    subCategory: 'Plastic items',
    tagline: 'Elegant "Pure Care" translucent design with textured dots in pink.',
    description: 'Part of our premium "Pure Care" range. Features a stylish transparent-tint dotted textured lid with a high-strength latch and a high-drainage internal separator grid.',
    wholesalePrice: 270,
    unitName: 'Box of 12 Cases (Pink)',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1605264964521-827db83501a4?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Color Option': 'Crystal Pink',
      'Material': 'Textured Clear Virgin PP',
      'Range Name': 'Pure Care Series',
      'Retail MRP': '₹65 per piece',
      'Wholesale Rate': '₹22.50 per piece'
    },
    blueprintShape: {
      neckWidth: 0.88,
      neckLength: 0.06,
      shoulderWidth: 0.82,
      shoulderHeight: 0.30,
      bellyWidth: 0.98,
      bellyHeight: 0.22,
      baseWidth: 0.78,
      totalHeightCm: 12
    }
  },
  {
    id: 'h-09',
    name: 'EVA Soap Case (Crystal Dot) - Blue',
    category: 'household',
    subCategory: 'Plastic items',
    tagline: 'Elegant "Pure Care" translucent design with textured dots in blue.',
    description: 'Part of our premium "Pure Care" range. Features a stylish transparent-tint dotted textured lid with a high-strength latch and a high-drainage internal separator grid.',
    wholesalePrice: 270,
    unitName: 'Box of 12 Cases (Blue)',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1528740561666-ac2479db0202?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Color Option': 'Crystal Blue',
      'Material': 'Textured Clear Virgin PP',
      'Range Name': 'Pure Care Series',
      'Retail MRP': '₹65 per piece',
      'Wholesale Rate': '₹22.50 per piece'
    },
    blueprintShape: {
      neckWidth: 0.88,
      neckLength: 0.06,
      shoulderWidth: 0.82,
      shoulderHeight: 0.30,
      bellyWidth: 0.98,
      bellyHeight: 0.22,
      baseWidth: 0.78,
      totalHeightCm: 12
    }
  },
  {
    id: 'h-10',
    name: 'EVA Soap Case (Crystal Dot) - Beige',
    category: 'household',
    subCategory: 'Plastic items',
    tagline: 'Elegant "Pure Care" translucent design with textured dots in beige.',
    description: 'Part of our premium "Pure Care" range. Features a stylish transparent-tint dotted textured lid with a high-strength latch and a high-drainage internal separator grid.',
    wholesalePrice: 270,
    unitName: 'Box of 12 Cases (Beige)',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Color Option': 'Crystal Amber/Beige',
      'Material': 'Textured Clear Virgin PP',
      'Range Name': 'Pure Care Series',
      'Retail MRP': '₹65 per piece',
      'Wholesale Rate': '₹22.50 per piece'
    },
    blueprintShape: {
      neckWidth: 0.88,
      neckLength: 0.06,
      shoulderWidth: 0.82,
      shoulderHeight: 0.30,
      bellyWidth: 0.98,
      bellyHeight: 0.22,
      baseWidth: 0.78,
      totalHeightCm: 12
    }
  },
  {
    id: 'h-11',
    name: 'CRISPY NEO LUNCH BOX',
    category: 'household',
    subCategory: 'Kitchen accessories',
    tagline: 'Ergonomic multiple-lock insulated plastic lunch box set',
    description: 'High-quality lunch container system featuring space-saving premium secure snap locks and food-grade airtight silicone safety gasket.',
    wholesalePrice: 1649.36,
    unitName: 'Box of 12 Units',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1599689017912-35a42095940c?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹104.00 per unit',
      'Basic Price' : '₹116.48 per unit',
      'Retail MRP' : '₹334.00',
      'Case Quantity' : '12 Units',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.70,
      neckLength: 0.10,
      shoulderWidth: 0.80,
      shoulderHeight: 0.40,
      bellyWidth: 0.90,
      bellyHeight: 0.30,
      baseWidth: 0.70,
      totalHeightCm: 14
    }
  },
  {
    id: 'h-12',
    name: 'CRISPY NXT LUNCH BOX',
    category: 'household',
    subCategory: 'Kitchen accessories',
    tagline: 'Advanced lock-tight leakproof dry lunch carrier set',
    description: 'Sleek, next-generation portable food box with heavy-duty hinges and superior pressure-release seal that keeps food fresh.',
    wholesalePrice: 1570.06,
    unitName: 'Box of 12 Units',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1621574539437-4b7cb63120b8?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹99.00 per unit',
      'Basic Price' : '₹110.88 per unit',
      'Retail MRP' : '₹317.00',
      'Case Quantity' : '12 Units',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.72,
      neckLength: 0.09,
      shoulderWidth: 0.82,
      shoulderHeight: 0.38,
      bellyWidth: 0.92,
      bellyHeight: 0.28,
      baseWidth: 0.72,
      totalHeightCm: 14
    }
  },
  {
    id: 'h-13',
    name: 'CRISPY LUNCH BOX',
    category: 'household',
    subCategory: 'Kitchen accessories',
    tagline: 'Classic dual-compartment robust school & office lunch box',
    description: 'Classic durable partition layout built from high-impact virgin polymers, featuring double snap-wings for extreme drop resistance.',
    wholesalePrice: 1538.34,
    unitName: 'Box of 12 Units',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹97.00 per unit',
      'Basic Price' : '₹108.64 per unit',
      'Retail MRP' : '₹310.00',
      'Case Quantity' : '12 Units',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.75,
      neckLength: 0.08,
      shoulderWidth: 0.85,
      shoulderHeight: 0.35,
      bellyWidth: 0.95,
      bellyHeight: 0.25,
      baseWidth: 0.75,
      totalHeightCm: 12
    }
  },
  {
    id: 'h-14',
    name: 'THERMO-COOL VACUUM STEEL BOTTLE 1000',
    category: 'household',
    subCategory: 'Kitchen accessories',
    tagline: 'Double-walled steel companion vacuum flask',
    description: 'Premium grade food-safe 18/8 stainless steel bottle offering elite vacuum insulation technology. Ideal for continuous travel or rigorous work cycles.',
    wholesalePrice: 540.53,
    unitName: 'Single Premium Bottle',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹409.00 per unit',
      'Basic Price' : '₹458.08 per unit',
      'Retail MRP' : '₹1,099.00',
      'Case Quantity' : '1 Bottle',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.30,
      neckLength: 0.18,
      shoulderWidth: 0.45,
      shoulderHeight: 0.55,
      bellyWidth: 0.60,
      bellyHeight: 0.25,
      baseWidth: 0.55,
      totalHeightCm: 32
    }
  },
  {
    id: 'h-15',
    name: 'PURE 1.5 1500 ML (STEEL CAP)',
    category: 'household',
    subCategory: 'Storage containers',
    tagline: 'Premium high-capacity clear fridge bottle with stainless steel cap',
    description: 'Perfect 1.5-liter storage vessel molded from crystal clean food-safe PET polymer. Features a high-integrity metal screw-threads cap to prevent spills.',
    wholesalePrice: 753.31,
    unitName: 'Box of 12 Bottles',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1523362628745-0c100150b504?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹47.50 per unit',
      'Basic Price' : '₹53.20 per unit',
      'Retail MRP' : '₹152.00',
      'Case Quantity' : '12 Bottles',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.32,
      neckLength: 0.15,
      shoulderWidth: 0.55,
      shoulderHeight: 0.58,
      bellyWidth: 0.65,
      bellyHeight: 0.28,
      baseWidth: 0.58,
      totalHeightCm: 29
    }
  },
  {
    id: 'h-16',
    name: 'PURE 1.5 1500 ML (P.C. CAP)',
    category: 'household',
    subCategory: 'Storage containers',
    tagline: 'Unbreakable premium fridge storage bottle with heavy poly-carbonate cap',
    description: 'High-clarity durable pet bottle featuring an extremely robust solid color Poly-carbonate cap designed for safe long-term cooling storage.',
    wholesalePrice: 753.31,
    unitName: 'Box of 12 Bottles',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1522204523234-e7edae5139c1?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹47.50 per unit',
      'Basic Price' : '₹53.20 per unit',
      'Retail MRP' : '₹152.00',
      'Case Quantity' : '12 Bottles',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.34,
      neckLength: 0.14,
      shoulderWidth: 0.54,
      shoulderHeight: 0.60,
      bellyWidth: 0.64,
      bellyHeight: 0.26,
      baseWidth: 0.56,
      totalHeightCm: 29
    }
  },
  {
    id: 'h-17',
    name: 'MANGO 1500 1500 ML',
    category: 'household',
    subCategory: 'Storage containers',
    tagline: 'Ergonomic heavy-ribbed grip fridge bottle set',
    description: 'Elegantly shaped 1500 ml fridge bottles molded with parallel slip-resistant ribs for superior tactile grip. Crafted from eco-friendly premium polymers.',
    wholesalePrice: 864.33,
    unitName: 'Box of 12 Bottles',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1608889175123-8ec330b86f84?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹54.50 per unit',
      'Basic Price' : '₹61.04 per unit',
      'Retail MRP' : '₹174.00',
      'Case Quantity' : '12 Bottles',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.33,
      neckLength: 0.13,
      shoulderWidth: 0.58,
      shoulderHeight: 0.57,
      bellyWidth: 0.68,
      bellyHeight: 0.27,
      baseWidth: 0.60,
      totalHeightCm: 28
    }
  },
  {
    id: 'h-18',
    name: 'VELVET 1500 1500 ML',
    category: 'household',
    subCategory: 'Storage containers',
    tagline: 'Luxurious velvet-smooth frosted fluid container',
    description: 'High-end cosmetic frosted-finish water server featuring smooth, micro-textured premium handfeel, strong puncture resistive shell, and thick base.',
    wholesalePrice: 864.33,
    unitName: 'Box of 12 Bottles',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹54.50 per unit',
      'Basic Price' : '₹61.04 per unit',
      'Retail MRP' : '₹174.00',
      'Case Quantity' : '12 Bottles',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.35,
      neckLength: 0.15,
      shoulderWidth: 0.55,
      shoulderHeight: 0.60,
      bellyWidth: 0.65,
      bellyHeight: 0.25,
      baseWidth: 0.55,
      totalHeightCm: 28
    }
  },
  {
    id: 'h-19',
    name: 'ARIZONA 1000 1000 ML',
    category: 'household',
    subCategory: 'Storage containers',
    tagline: 'Compact high-rigidity heavy structural gyms and fridge bottle',
    description: 'Built-to-last 1000 ml water holder engineered using a heavy density thick-wall process. Designed with an easy-sip custom flow cap.',
    wholesalePrice: 824.68,
    unitName: 'Box of 12 Bottles',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹52.00 per unit',
      'Basic Price' : '₹58.24 per unit',
      'Retail MRP' : '₹167.00',
      'Case Quantity' : '12 Bottles',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.34,
      neckLength: 0.12,
      shoulderWidth: 0.52,
      shoulderHeight: 0.54,
      bellyWidth: 0.62,
      bellyHeight: 0.23,
      baseWidth: 0.54,
      totalHeightCm: 24
    }
  },
  {
    id: 'h-20',
    name: 'FLORIDA 1000 1000 ML',
    category: 'household',
    subCategory: 'Storage containers',
    tagline: 'Minimalist clean-cylindrical hydration bottle',
    description: 'Perfect round-body minimalist fluid model created using advanced transparency resins. Aesthetic design matching stylish dining and travel sets.',
    wholesalePrice: 824.68,
    unitName: 'Box of 12 Bottles',
    minOrderQty: 1,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1548839140-29a8a18fa394?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Purchase Price' : '₹52.00 per unit',
      'Basic Price' : '₹58.24 per unit',
      'Retail MRP' : '₹167.00',
      'Case Quantity' : '12 Bottles',
      'GST Rate' : '18%'
    },
    blueprintShape: {
      neckWidth: 0.32,
      neckLength: 0.13,
      shoulderWidth: 0.50,
      shoulderHeight: 0.55,
      bellyWidth: 0.60,
      bellyHeight: 0.24,
      baseWidth: 0.52,
      totalHeightCm: 24
    }
  },

  // --- PACKING MATERIALS ---
  {
    id: 'p-01',
    name: 'Double-Layer Transit Bubble Wrap Roll',
    category: 'packing',
    subCategory: 'Bubble wrap',
    tagline: 'High-burst-strength dual laminate protective cushioning wrapping.',
    description: '10mm bubble diameter with uniform gas retention barriers. Ensures continuous cushioning pressure against severe shunts and transit vibration for sensitive household glassware and industrial items.',
    wholesalePrice: 950,
    unitName: 'Roll (1.2m Width x 100m Length)',
    minOrderQty: 8,
    gstRate: 12,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Bubble Diameter': '10 mm',
      'Roll Width': '1.2 Meters',
      'Total Length': '100 Meters',
      'Cushion Ply': 'Double Layer Laminated'
    },
    blueprintShape: {
      neckWidth: 0.35,
      neckLength: 0.25,
      shoulderWidth: 0.35,
      shoulderHeight: 0.50,
      bellyWidth: 0.70,
      bellyHeight: 0.30,
      baseWidth: 0.70,
      totalHeightCm: 120
    }
  },
  {
    id: 'p-02',
    name: 'Ultra-Adhesive Brown Carton Tape (3-Inch)',
    category: 'packing',
    subCategory: 'Tape',
    tagline: '50-micron high-bond acrylic tape for heavy corrugated cardboard box sealing.',
    description: 'Water-resistant polymer film with heavy hot-melt aggressive adhesive backing. Stays bonded under high moisture, humid Kerala export transits, and refrigeration climates without popping loose.',
    wholesalePrice: 780,
    unitName: 'Box of 24 Heavy Rolls',
    minOrderQty: 5,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Tape Width': '72 mm (3 Inches)',
      'Film Gauge': '50 Microns',
      'Roll Core': 'Thick Hardened Kraft Paperboard',
      'Adhesive': 'Aggressive Moisture-Guard Acrylic'
    },
    blueprintShape: {
      neckWidth: 0.45,
      neckLength: 0.20,
      shoulderWidth: 0.50,
      shoulderHeight: 0.45,
      bellyWidth: 0.60,
      bellyHeight: 0.25,
      baseWidth: 0.55,
      totalHeightCm: 10
    }
  },
  {
    id: 'p-03',
    name: 'Heavy-Duty 5-Ply Corrugated Shipping Boxes',
    category: 'packing',
    subCategory: 'Corrugated boxes',
    tagline: 'Flute-reinforced high burst factor structural packing cartons.',
    description: 'Reinforced BC double-wall flute boards built from 100% biodegradable unbleached organic pine wood pulp. Protects heavy goods, domestic electrical, and packed products during stacking and logistics loading.',
    wholesalePrice: 2400,
    unitName: 'Bundle of 50 Flat Boxes',
    minOrderQty: 4,
    gstRate: 12,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1512909006721-3d6018887383?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Metric Size': '45cm x 45cm x 45cm',
      'Bursting Factor': '24 kgF/cm²',
      'Ply Rating': '5-Ply (Double Fluted Wall)',
      'Structural Capacity': 'Up to 35 kg Stack Limit'
    },
    blueprintShape: {
      neckWidth: 0.40,
      neckLength: 0.30,
      shoulderWidth: 0.80,
      shoulderHeight: 0.50,
      bellyWidth: 0.90,
      bellyHeight: 0.35,
      baseWidth: 0.85,
      totalHeightCm: 45
    }
  },
  {
    id: 'p-04',
    name: 'Premium Cast Stretch Film Packaging Rolls',
    category: 'packing',
    subCategory: 'Packaging rolls',
    tagline: 'High-stretch elastic pallet stretch film for heavy cargo consolidation.',
    description: 'Made of linear low-density polyethylene (LLDPE) ensuring massive puncture resistance and quiet high stretch ratios up to 300%. Protects wholesale cardboard stacks from moisture, rain, and scuffing.',
    wholesalePrice: 1650,
    unitName: 'Box of 4 Industrial Rolls',
    minOrderQty: 6,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Roll Width': '50 cm',
      'Film Thickness': '23 Microns Super-Puncture',
      'Elongation Limit': '300% Multi-Stretch',
      'Weight Per Roll': '3.2 kg Commercial'
    },
    blueprintShape: {
      neckWidth: 0.30,
      neckLength: 0.22,
      shoulderWidth: 0.30,
      shoulderHeight: 0.40,
      bellyWidth: 0.45,
      bellyHeight: 0.25,
      baseWidth: 0.45,
      totalHeightCm: 50
    }
  },
  {
    id: 'p-05',
    name: 'Durable Recyclable Loop-Handle Carry Bags',
    category: 'packing',
    subCategory: 'Carry bags',
    tagline: 'Degradable eco-certified heavy-gauge grocery checkout carry bags.',
    description: 'Gusseted-wall shopping carry bags designed with comfortable robust welded loop handles. Formulated for high weight support, food contact safety, and quick retail supermarket checkouts across Kerala.',
    wholesalePrice: 1120,
    unitName: 'Bale of 1000 Premium Bags',
    minOrderQty: 10,
    gstRate: 18,
    isAvailable: true,
    imageUrl: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=400&q=80',
    specifications: {
      'Bag Dimension': '16 x 20 Inches + 4 Inch Gusset',
      'Thickness Gauge': '55 Microns Reinforced',
      'Certification': 'ISO Eco-Cycle Degradability',
      'Box Pack Count': '10 Packs of 100 bags'
    },
    blueprintShape: {
      neckWidth: 0.65,
      neckLength: 0.20,
      shoulderWidth: 0.85,
      shoulderHeight: 0.45,
      bellyWidth: 1.05,
      bellyHeight: 0.30,
      baseWidth: 0.65,
      totalHeightCm: 50
    }
  }
];

export function getWhatsAppUrl(productName: string, queryType: string = 'pre-launch wholesale enquiry') {
  const adminPhone = '919446051515'; // Professional Kerala wholesale partner contact
  const text = `Hello Prime Traders Thiruvananthapuram! I see your shop is debuting soon at Chalai Bazaar. I want to pre-register/make a ${queryType} for: "${productName}". Please send your wholesale reseller price sheet and custom volume brackets. Thank you!`;
  return `https://wa.me/${adminPhone}?text=${encodeURIComponent(text)}`;
}

export function getProductResellerInfo(product: WholesaleProduct) {
  if (product.resellerInfo) {
    return product.resellerInfo;
  }
  
  const sub = product.subCategory.toLowerCase();
  
  if (sub.includes('cleaning') || sub.includes('squeegee')) {
    return {
      estimatedRetailMargin: '35% - 50% High Margin',
      targetRetailSegment: 'Cleaning Outlets, Hotel Suppliers, Hardware Stores',
      packagingOptions: 'Bulk Carton Packs with Private Label Support',
    };
  } else if (sub.includes('storage') || sub.includes('canister') || sub.includes('jar')) {
    return {
      estimatedRetailMargin: '25% - 40% Retail Markup',
      targetRetailSegment: 'Homeware Stores, Supermarkets, Kitchen Boutiques',
      packagingOptions: 'Pre-packaged Retail Box Sets or Custom Branding',
    };
  } else if (sub.includes('plastic') || sub.includes('basin') || sub.includes('tub')) {
    return {
      estimatedRetailMargin: '30% - 45% High Demand',
      targetRetailSegment: 'General Provision Shops, Catering Services, Hardware Centers',
      packagingOptions: 'Nestable stacks with volume barcoding options',
    };
  } else if (sub.includes('tape') || sub.includes('adhesive')) {
    return {
      estimatedRetailMargin: '20% - 35% Volume Mover',
      targetRetailSegment: 'Logistics Centers, Stationery Retailers, E-commerce Warehouses',
      packagingOptions: 'Shrink-wrapped tower sleeves with custom print core',
    };
  } else if (sub.includes('box') || sub.includes('carton') || sub.includes('corrugated')) {
    return {
      estimatedRetailMargin: '15% - 30% Steady Turn',
      targetRetailSegment: 'Courier Services, Moving agencies, Packaging dealers',
      packagingOptions: 'Flat bundles of 25 with heat-sealed strap ties',
    };
  } else if (sub.includes('carry') || sub.includes('bag')) {
    return {
      estimatedRetailMargin: '20% - 35% Daily Essential',
      targetRetailSegment: 'Retail checkout counters, Bakeries, Supermarkets',
      packagingOptions: 'Hanging-eye loop handle bales ready for billing stands',
    };
  }
  
  return {
    estimatedRetailMargin: '25% - 40% Dynamic Margin',
    targetRetailSegment: 'Wholesalers, General Retailers, Commercial outlets',
    packagingOptions: 'Bulk bundle packaging with regional dealer support',
  };
}

export function getCartWhatsAppUrl(cartItems: Array<{ product: WholesaleProduct; qty: number }>, businessInfo: { shopName: string; location: string; phone: string }) {
  const adminPhone = '919446051515';
  let listText = '';
  cartItems.forEach((item, idx) => {
    listText += `\n${idx + 1}. ${item.product.name} (Qty: ${item.qty} units, Pack size: ${item.product.unitName})`;
  });

  const text = `*PRIME TRADERS THIRUVANANTHAPURAM (CHALAI) - PRE-LAUNCH B2B QUOTATION BRIEF*
  
*Distributor Details:*
🏬 Shop/Hotel Name: ${businessInfo.shopName || 'Not Specified'}
📍 Delivery Location Selected: ${businessInfo.location || 'Thiruvananthapuram'}
📞 Phone Contact: ${businessInfo.phone || 'Provided'}

*Pre-Registered Items List:*${listText}

*Enquiry note:*
We have selected the above products to query for custom wholesale pricing, bulk margins, and reselling licensing. Please register our B2B interest for when the Prime Traders Chalai branch opens and send us a tailored quote. Thank you.`;

  return `https://wa.me/${adminPhone}?text=${encodeURIComponent(text)}`;
}
